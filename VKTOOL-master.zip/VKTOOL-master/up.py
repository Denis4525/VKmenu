import os
os.system("cd")
os.system("rm -rf VKTOOL")
os.system("git clone https://github.com/darkcoding12/VKTOOL")
